# Utvecklingsmiljö

En utvecklingsmiljö för HTML och CSS.

Det finns olika sätt att arbeta och publicera:

1. **Utveckla** i molnet med **GitHub Codespaces**.
2. **Publicera** gratis direkt från GitHub med **GitHub Pages**.
3. **Publicera** med högskolans tjänst **Webshare**.

---

## Innan du börjar: GitHub Student Developer Pack

För att använda Codespaces gratis behöver du registrera dig för GitHub Student Developer Pack med din högskolemail.

1. Gå till [GitHub Student Developer Pack](https://education.github.com/pack)
2. Klicka på **"Sign up for Student Developer Pack"**
3. Skapa ett **GitHub konto**
4. Verifiera med din **@stud.hkr.se**-adress
5. Efter inloggning klicka på knappen **"Start an application"** (via [GitHub Education Benefits](https://github.com/settings/education/benefits))
6. Välj **Student**
7. Välj **lärosäte**, exempelvis Högskolan Kristianstad
8. Klicka på knappen **Share Location**
9. Klicka på knappen **Continue**
10. Välj alternativet **3. Dated enrollment letter on school letterhead** under knappen **Select...**
11. Gå till **LADOK** (via [https://student.ladok.se/](https://student.ladok.se/))
12. Gå till **Intyg** → **Skapa intyg** → **Registreringsintyg** → Välj **period** och ange språk till **Engelska**
13. Använd **webbkamera eller mobilen** för att ta bild på registreringsintyget → Tryck på knappen **Capture**
14. Välj alternativet **All coursework is via distance learning** om du läser på distans
15. **IGEN** Använd **webbkamera eller mobilen** för att ta bild på registreringsintyget → Tryck på knappen **Capture**
16. Du ska nu ha fått beskedet **Your application has been submitted**

**OBS:** Det kan ta upp till **24 timmar** innan förmånerna aktiveras.

## Om du får beskedet Denied

1. Kontrollera att du har aktiverat **two-factor authentication** under [GitHub Security](https://github.com/settings/security).
2. Uppdatera din **Billing information** under [GitHub Billing Information](https://github.com/settings/billing/payment_information). Ange fullständigt namn, måste matcha LADOK intyget.
3. Uppdatera din **Profile** → Klicka på **ikonen längst upp till höger** → Välj Profile → Klicka på knappen **Edit profile** → Uppdatera ditt **fullständiga namn** → Logga ut och in igen → Ansök på nytt via [GitHub Education Benefits](https://github.com/settings/education/benefits).
4. Upprepa steg 5-16 enligt ovan. **OBS! Ibland funkar det snabbare om man zoomar in på tre detaljer:**
   a) Ditt fullständiga namn
   b) Namn på högskolan/universitetet
   c) Beskrivning som indikerar distansutbildning
5. **Ibland kan det ta över 5 gånger** innan ansökan går igenom och det beror på att varje gång checkar systemet av ovanstående tre detaljer.

### Vad ingår?
| Förmån | Beskrivning |
|--------|-------------|
| **GitHub Pro** | Obegränsade privata repos |
| **Copilot Pro** | AI-kodassistent gratis |
| **Codespaces** | 180 timmar/månad för molnkodning |

---

## Hantera dina Codespaces-timmar

### Kontrollera återstående timmar
1. Gå till **github.com** → Klicka på din profilbild → **Settings**
2. **Billing and licensing** → **Overview**
3. Under **Metered usage**, klicka på **Codespaces**
4. Klicka på **View details** till höger

### Automatisk timeout
En Codespace stängs automatiskt efter **30 minuters inaktivitet**. Din kod sparas och du slutar förbruka timmar.

### Stäng manuellt (rekommenderas!)

| Metod | Instruktion |
|-------|-------------|
| **Kortkommando** | `Cmd+Shift+P` (Mac) / `Ctrl+Shift+P` (Win) → Skriv "stop" → **Stop Current Codespace** |
| **Från GitHub** | [github.com/codespaces](https://github.com/codespaces) → Klicka på knappen **<> Code** → Välj fliken **Codespaces** → Klicka på **⋯** → **Stop codespace** |

Din kod försvinner inte – nästa gång fortsätter du där du slutade!

---

## 1. Codespaces – utveckla i molnet

1. Klicka på den **gröna knappen "Use this template"** längst upp till höger på den här sidan → välj **"Open in a codespace"**.
2. Vänta medan miljön byggs (ca 1 minut första gången).
3. Webbservern startar automatiskt. Klicka på **PORTS**-fliken och öppna länken vid port **3000** för att se din webbplats.
4. Redigera `index.html` och `assets/css/style.css` — spara så uppdateras sidan automatiskt i webbläsaren.

## Filstruktur

```
/
├── index.html              ← Startsida (redigera denna)
├── assets/
│   ├── css/
│   │   └── style.css       ← Din CSS (redan länkad i index.html)
│   └── images/             ← Lägg dina bilder här
└── .devcontainer/          ← Konfiguration (rör ej)
```

---

## 2. GitHub Pages – publicera gratis via GitHub

GitHub Pages publicerar din statiska webbplats (HTML/CSS) direkt från ditt repo helt gratis och utan FTP.

**Förutsättningar:** Du behöver ett **eget repo** (skapa ett via den gröna knappen **"Use this template"**, se steg 1 under Codespaces) och repot måste vara **publikt** (privata repo kräver GitHub Pro, vilket ingår i Student Developer Pack).

1. Se till att din kod (`index.html` m.fl.) är **committad och pushad** till `main`.
2. Gå till ditt repo på **github.com** → klicka på fliken **Settings** högst upp.
3. I vänstermenyn, under "Code and automation", välj **Pages**.
4. Under **Build and deployment** → **Source**, välj **Deploy from a branch**.
5. Under **Branch**, välj **`main`** och mappen **`/ (root)`** → klicka **Save**.
6. Vänta ca **1 minut** och ladda om sidan. En ruta högst upp visar adressen till din publicerade webbplats:

   **`https://<användarnamn>.github.io/<repo-namn>/`**
7. Klicka på **Visit site** för att öppna din webbplats.

**Bra att veta:**

| Fråga | Svar |
|-------|------|
| **Uppdatera sidan** | Varje gång du pushar nya ändringar till `main` byggs webbplatsen om automatiskt inom någon minut. |
| **Får en 404?** | Kontrollera att filen heter exakt **`index.html`** och ligger i **roten** av repot (inte i en undermapp). |
| **Bilder syns inte?** | Använd relativa sökvägar, t.ex. `assets/images/min-bild.jpg` — inte sökvägar som börjar med `/`. |

---

## 3. Webshare – publicera din webbplats

Webshare är högskolans tjänst för att publicera din egen webbplats på en publik adress.

1. Aktivera ditt konto via **[webshare-aktivera.hkr.se](https://www.webshare-aktivera.hkr.se)**.
2. Anslut med en **FTP-klient** (t.ex. FileZilla) med dessa uppgifter:

   | Inställning | Värde |
   |-------------|-------|
   | Värd (host) | `www.webshare.hkr.se` |
   | Användare | ditt **inloggningsnamn** |
   | Lösenord | ditt vanliga lösenord |
   | Inloggningstyp | **Normal** (krävs i vissa FTP-klienter) |

   Alternativt: skriv `ftp://www.webshare.hkr.se/` i webbläsarens adressfält, logga in och följ instruktionerna.
3. I din startmapp (samma namn som ditt inloggningsnamn) finns en färdig startsida `default.asp`.
4. För en egen HTML-sida — ersätt den med en fil som heter **`index.html`**.
5. Din webbplats blir då tillgänglig på: **`https://www.webshare.hkr.se/inloggningsnamn`**

<!-- everydaydesign · webdesign course -->
